#!/usr/bin/env python3
"""Manual power routing for TMC_PSU: pours, fat tracks, stitch vias, keepouts.
All coordinates hand-verified against measured pad geometry. Nets completed here
get emptied from the FreeRouting DSN later: GND +12V +12V_IN +5V1 SW FB BOOT QG
BRA_* BRB_* MA_* MB_* CPO_* CPI_* VCP_* V5OUT_*."""
import pcbnew, sys
FM, TM = pcbnew.FromMM, pcbnew.ToMM
PCB = '/home/claude/tmc/TMC_PSU.kicad_pcb'
b = pcbnew.LoadBoard(PCB)
def _net(name):
    n = b.FindNet(name)
    assert n is not None, f"net missing: {name}"
    return n.GetNetCode()
class _N(dict):
    def __missing__(self, k):
        v = self[k] = _net(k)
        return v
nets = _N()
F, B = pcbnew.F_Cu, pcbnew.B_Cu

def track(x1, y1, x2, y2, w, net, layer=F):
    t = pcbnew.PCB_TRACK(b)
    t.SetStart(pcbnew.VECTOR2I(FM(x1), FM(y1)))
    t.SetEnd(pcbnew.VECTOR2I(FM(x2), FM(y2)))
    t.SetWidth(FM(w)); t.SetLayer(layer); t.SetNetCode(nets[net]); b.Add(t)

def path(pts, w, net, layer=F):
    for a, c in zip(pts, pts[1:]):
        track(a[0], a[1], c[0], c[1], w, net, layer)

def via(x, y, net, size=0.6, drill=0.3):
    v = pcbnew.PCB_VIA(b)
    v.SetPosition(pcbnew.VECTOR2I(FM(x), FM(y)))
    v.SetDrill(FM(drill)); v.SetWidth(FM(size))
    v.SetViaType(pcbnew.VIATYPE_THROUGH)
    v.SetLayerPair(F, B); v.SetNetCode(nets[net]); b.Add(v)

def zone(pts, layer, net, prio):
    z = pcbnew.ZONE(b)
    z.SetLayer(layer); z.SetNet(b.FindNet(net))
    o = z.Outline(); o.NewOutline()
    for px, py in pts:
        o.Append(FM(px), FM(py))
    z.SetPadConnection(pcbnew.ZONE_CONNECTION_FULL)
    z.SetLocalClearance(FM(0.2)); z.SetMinThickness(FM(0.25))
    z.SetAssignedPriority(prio)
    b.Add(z)
    return z

def rect(x0, y0, x1, y1):
    return [(x0, y0), (x1, y0), (x1, y1), (x0, y1)]

# ---------------- zones ----------------
# F.Cu +12V_IN pocket: J1-1 + Q1 input pads
zone(rect(3.8, 5.8, 13.35, 18.2), F, '+12V_IN', 2)

# B.Cu +12V: top band with 4 sense-resistor notches (GND pockets), left arm, two fingers
band = [(13.5, 4.5), (70, 4.5), (70, 14.5),
        (66.0, 14.5), (66.0, 8.6), (64.4, 8.6), (64.4, 14.5),
        (54.5, 14.5), (54.5, 8.6), (52.9, 8.6), (52.9, 14.5),
        (40.0, 14.5), (40.0, 8.6), (38.4, 8.6), (38.4, 14.5),
        (28.5, 14.5), (28.5, 8.6), (26.9, 8.6), (26.9, 14.5),
        (13.5, 14.5)]
zone(band, B, '+12V', 1)
zone(rect(13.5, 4.5, 22, 43.5), B, '+12V', 2)      # left arm down to buck
zone(rect(26.6, 13.5, 29.4, 24.0), B, '+12V', 3)   # finger to C16
zone(rect(52.6, 13.5, 55.4, 24.0), B, '+12V', 3)   # finger to C21

# F.Cu +5V1: buck output region + USB tongue
zone(rect(30.5, 36.5, 44, 52.8), F, '+5V1', 1)
zone(rect(25, 50, 35, 59.7), F, '+5V1', 2)

# antenna edge keepout (both layers): no pour/tracks/vias under antenna sliver
for lay in (F, B):
    z = pcbnew.ZONE(b)
    z.SetLayer(lay)
    z.SetIsRuleArea(True)
    z.SetDoNotAllowZoneFills(True)
    z.SetDoNotAllowTracks(True)
    z.SetDoNotAllowVias(True)
    o = z.Outline(); o.NewOutline()
    for px, py in rect(90.8, 22, 92, 44):
        o.Append(FM(px), FM(py))
    b.Add(z)

# ---------------- 12V input hot path ----------------
# QG gate pulldown wiring
path([(12.225, 13.3), (16.5, 7.1), (17.97, 7.1)], 0.3, 'QG')
# D1/+12V, C1/C2, C3/C4, U1-VIN, Q1-out stitch vias (F pad -> B +12V region)
for x, y, sx, sy, w in [
    (19.4, 8.4,  17.97, 8.37, 0.8),    # Q1 out
    (19.4, 10.9, 17.97, 10.91, 0.8),
    (17.7, 18.2, 17.7, 16.5, 0.8),     # D1-2 (SMB +12V pad)
    (14.2, 20.8, 13.6, 22.5, 0.8),     # C1-1
    (14.2, 28.3, 13.6, 30, 0.8),       # C2-1
    (20.4, 35.4, 18.94, 35.4, 0.8),    # C3-1
    (14.15, 34.05, 13.775, 35.4, 0.6),# C4-1
    (16.6, 39.36, 15.47, 39.36, 0.5),  # U1-7 VIN
]:
    via(x, y, '+12V'); track(sx, sy, x, y, w, '+12V')

# ---------------- buck SW node ----------------
# pin8 -> C5-2(SW) -> L1-1, branch to D2-1
path([(15.47, 38.09), (18.825, 38.3)], 0.6, 'SW')
path([(18.825, 38.3), (19.0, 39.3)], 0.8, 'SW')
path([(19.0, 39.3), (23.35, 40.0)], 1.2, 'SW')
path([(23.35, 40.0), (23.35, 41.5), (21.8, 43.0), (16.0, 45.2), (13.1, 47.2), (13.1, 48.5)], 2.0, 'SW')
# BOOT: C5-1 -> around north of U1 -> pin1
path([(20.375, 38.3), (21.2, 37.6), (21.2, 33.7), (10.4, 33.7), (10.4, 38.09), (10.53, 38.09)], 0.25, 'BOOT')
# FB divider: R2-2/R3-1 -> U1 pin4
path([(5.0, 43.225), (7.5, 43.225)], 0.25, 'FB')
path([(7.5, 43.225), (10.53, 41.91)], 0.25, 'FB')
# FB 5V sense: F zone tap -> B.Cu -> R2-1
via(31.2, 44.5, '+5V1')
path([(31.2, 44.5), (6.2, 44.5)], 0.3, '+5V1', B)
via(6.2, 44.5, '+5V1')
path([(6.2, 44.5), (5.0, 44.775)], 0.3, '+5V1')
# R4/R5 CC pullup +5V1 stubs east into main zone
track(29.475, 47.6, 30.7, 47.6, 0.4, '+5V1')
track(29.475, 49.4, 30.7, 49.4, 0.4, '+5V1')
# D5-2 anode is inside main 5V zone (40.5,46.3) - covered. D4-2 LED (37,53.725) in tongue? x=37>35: stub
track(37, 53.725, 35.2, 53.0, 0.4, '+5V1')
track(35.2, 53.0, 34.6, 52.6, 0.4, '+5V1')

# ---------------- TMC top-face escapes (identical A/B, offset +26 in x) ----------------
for dx, s in ((0.0, 'A'), (26.0, 'B')):
    X = lambda x: x + dx
    # +12V pins 22/28 -> in-band vias (same-net adjacency with own pads)
    via(X(35.3), 13.75, '+12V'); track(X(35.0), 14.55, X(35.3), 13.75, 0.4, '+12V')
    via(X(31.7), 13.95, '+12V'); track(X(32.0), 14.55, X(31.7), 13.95, 0.4, '+12V')
    # sense: BRA pin23 -> north -> east lane y=13.1 -> R (x+? ) pad1 bottom (x,13.27)
    path([(X(34.5), 14.55), (X(34.5), 13.2), (X(34.7), 13.1), (X(39.0), 13.1), (X(39.2), 13.27)], 0.25, f'BRA_{s}')
    # BRB pin27 -> north -> west lane y=13.35 -> R pad1 (x-6.5? A: 27.7)
    path([(X(32.5), 14.55), (X(32.5), 13.35), (X(27.7), 13.35), (X(27.7), 13.27)], 0.25, f'BRB_{s}')
    # sense GND ends -> vias in band notches
    via(X(39.2), 9.05, 'GND'); track(X(39.2), 10.33, X(39.2), 9.05, 0.5, 'GND')
    via(X(27.7), 9.05, 'GND'); track(X(27.7), 10.33, X(27.7), 9.05, 0.5, 'GND')
    # motor fans (J pin order B2 B1 A1 A2 at x 26/31/36/41 +dx)
    m = 'MA' if s == 'A' else 'MB'
    path([(X(31.05), 15.5), (X(30.4), 15.5)], 0.3, f'{m}_B2')
    path([(X(30.4), 15.5), (X(25.5), 15.5)], 0.8, f'{m}_B2')
    path([(X(25.5), 15.5), (X(25.5), 6.5), (X(26.0), 4.6)], 1.0, f'{m}_B2')
    path([(X(33.0), 14.55), (X(33.0), 12.4)], 0.3, f'{m}_B1')
    path([(X(33.0), 12.4), (X(31.7), 10.2), (X(31.0), 5.8), (X(31.0), 4.6)], 0.8, f'{m}_B1')
    path([(X(34.0), 14.55), (X(34.0), 12.4)], 0.3, f'{m}_A1')
    path([(X(34.0), 12.4), (X(36.3), 9.5), (X(36.0), 4.6)], 0.8, f'{m}_A1')
    path([(X(35.95), 15.5), (X(37.2), 15.5)], 0.3, f'{m}_A2')
    path([(X(37.2), 15.5), (X(40.9), 15.9), (X(41.3), 14.8), (X(41.3), 6.2), (X(41.0), 4.6)], 0.8, f'{m}_A2')
    # VS decoupler C19/C24: +12V via in band, GND stub-around via below band
    via(X(42.6), 13.85, '+12V'); track(X(42.6), 12.775, X(42.6), 13.85, 0.5, '+12V')
    via(X(43.8), 15.3, 'GND')
    path([(X(42.6), 11.225), (X(43.8), 12.0), (X(43.8), 15.3)], 0.4, 'GND')
    # charge pump + VCP + 5VOUT support hookups
    path([(X(31.05), 17.0), (X(30.1), 17.0), (X(28.45), 17.75), (X(28.0), 17.825)], 0.25, f'CPO_{s}')
    path([(X(31.05), 17.5), (X(30.4), 17.5), (X(28.45), 19.375), (X(28.0), 19.375)], 0.25, f'CPI_{s}')
    path([(X(31.05), 18.0), (X(30.3), 18.0), (X(28.9), 20.5), (X(28.45), 21.025), (X(28.0), 21.025)], 0.25, f'VCP_{s}')
    path([(X(32.0), 19.45), (X(31.775), 22.5)], 0.3, f'V5OUT_{s}')
    # C16 VCP-cap +12V pad -> finger via
    via(X(28.0), 23.6, '+12V'); track(X(28.0), 22.575, X(28.0), 23.6, 0.5, '+12V')
    # TMC side GND pins -> EP stubs (EP box 31.825..35.175 x 15.325..18.675 +dx)
    stubs = [(31.05, 16.5, 32.5, 16.5), (31.05, 18.5, 32.5, 18.5),
             (33.0, 19.45, 33.0, 18.3), (34.5, 19.45, 34.5, 18.3),
             (35.95, 17.0, 34.8, 17.0), (35.95, 17.5, 34.8, 17.5),
             (35.95, 16.0, 34.9, 16.0)]
    if s == 'A':
        stubs.append((32.5, 19.45, 32.5, 18.3))   # pin9 GND only on U2
    for gx, gy, ex, ey in stubs:
        track(X(gx), gy, X(ex), ey, 0.25, 'GND')

# ---------------- GND stitch vias (F SMD pad -> B plane) ----------------
gnd = [
    # (via x, via y, stub from x, stub from y, w)
    (12.3, 11.9, 13.775, 13.3, 0.4),      # R1-2
    (11.5, 16.5, 13.3, 16.5, 0.8),        # D1-1
    (22.6, 22.5, 18.4, 22.5, 1.0),        # C1-2
    (22.6, 30.0, 18.4, 30.0, 1.0),        # C2-2
    (11.1, 34.2, 12.225, 35.4, 0.4),      # C4-2
    (16.6, 44.2, None, None, 0),          # spare plane via under buck
    (8.4, 45.8, 7.5, 44.775, 0.4),        # R3-2
    (19.5, 47.8, None, None, 0),          # D2-2 in-pad
    (20.3, 49.2, None, None, 0),          # D2-2 in-pad
    (42.2, 40.0, 40.7, 40.0, 0.8),        # C6-2
    (34.4, 44.3, 33.3, 45.56, 0.5),       # C7-2
    (38.2, 44.3, 37.0, 45.56, 0.5),       # C8-2
    (45.0, 38.2, 45.0, 39.56, 0.5),       # C9-2
    (58.0, 41.3, 58.0, 42.56, 0.5),       # C10-2
    (61.0, 42.0, 61.0, 43.225, 0.4),      # C11-2
    (48.35, 40.3, 48.35, 41.7, 0.5),      # U4-1
    (30.1, 24.1, 30.225, 22.5, 0.4),      # C17-2
    (36.075, 24.0, 36.075, 22.5, 0.4),    # C18-2
    (56.1, 24.1, 56.225, 22.5, 0.4),      # C22-2
    (62.075, 24.0, 62.075, 22.5, 0.4),    # C23-2
    (40.7, 56.5, 39.5, 55.775, 0.4),      # R6-2
    (61.9, 38.9, 62.725, 40.0, 0.4),      # R10-2
    (47.5, 54.1, 47.5, 52.775, 0.4),      # R11-2
    (49.5, 54.1, 49.5, 52.775, 0.4),      # R12-2
    (81.725, 20.2, 81.725, 21.5, 0.4),    # C12-2
    (77.94, 19.9, 77.94, 21.2, 0.5),      # C13-2
    (72.775, 20.2, 72.775, 21.5, 0.4),    # C14-2
    (86.0, 48.3, 86.0, 46.8, 0.5),        # SW1-2 (bar below)
    (80.0, 48.3, 80.0, 46.8, 0.5),        # SW2-2
    (26.2, 58.2, 26.75, 58.89, 0.5),      # J2 A12/B1
    (33.8, 58.2, 33.25, 58.89, 0.5),      # J2 A1/B12
    (53.7, 58.2, 54.25, 58.89, 0.5),      # J3 A12/B1
    (61.3, 58.2, 60.75, 58.89, 0.5),      # J3 A1/B12
    (90.3, 23.1, 90.26, 24.25, 0.5),      # U5 pad1
    (90.3, 42.9, 90.26, 41.75, 0.5),      # U5 pad40
    (81.6, 30.7, None, None, 0),          # U5 EP in-pad x4
    (83.4, 30.7, None, None, 0),
    (81.6, 32.3, None, None, 0),
    (83.4, 32.3, None, None, 0),
]
for vx, vy, sx, sy, w in gnd:
    via(vx, vy, 'GND')
    if sx is not None:
        track(sx, sy, vx, vy, w, 'GND')
# SW buttons: bridge both pad2 halves then drop
track(83.95, 46.8, 88.05, 46.8, 0.5, 'GND')
track(77.95, 46.8, 82.05, 46.8, 0.5, 'GND')
# C3-2 -> U1 EP (F.Cu GND stub)
path([(16.06, 35.4), (14.6, 37.2), (13.6, 38.6)], 0.5, 'GND')
# U1 pin6 -> EP
track(15.47, 40.64, 14.0, 40.64, 0.4, 'GND')

pcbnew.SaveBoard(PCB, b)
print("power routing saved:",
      len([t for t in b.Tracks() if t.GetClass() == 'PCB_VIA']), "vias,",
      len([t for t in b.Tracks() if t.GetClass() != 'PCB_VIA']), "tracks,",
      len(list(b.Zones())), "zones")
