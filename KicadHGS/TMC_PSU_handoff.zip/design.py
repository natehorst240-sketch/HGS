#!/usr/bin/env python3
"""Dual TMC2209 + ESP32-S3 + 12V->5.1V/5A USB-C (Pi 5, EEPROM approach) board definition.
Every footprint is a stock KiCad library part. Pin maps verified against official symbols
(TMC2209-LA, ESP32-S3-WROOM-1) and the TI TPS5450 datasheet."""

FP = {
    'TMC':    'Package_DFN_QFN:QFN-28-1EP_5x5mm_P0.5mm_EP3.35x3.35mm_ThermalVias',
    'ESP':    'RF_Module:ESP32-S3-WROOM-1',
    'BUCK':   'Package_SO:SOIC-8-1EP_3.9x4.9mm_P1.27mm_EP2.29x3mm_ThermalVias',
    'USB':    'Connector_USB:USB_C_Receptacle_HRO_TYPE-C-31-M-12',
    'TB2':    'TerminalBlock:TerminalBlock_MaiXu_MX126-5.0-02P_1x02_P5.00mm',
    'TB4':    'TerminalBlock:TerminalBlock_MaiXu_MX126-5.0-04P_1x04_P5.00mm',
    'SOT223': 'Package_TO_SOT_SMD:SOT-223-3_TabPin2',
    'SOIC8':  'Package_SO:SOIC-8_3.9x4.9mm_P1.27mm',
    'SMA':    'Diode_SMD:D_SMA',
    'SMB':    'Diode_SMD:D_SMB',
    'SMC':    'Diode_SMD:D_SMC',
    'R0603':  'Resistor_SMD:R_0603_1608Metric',
    'R1206':  'Resistor_SMD:R_1206_3216Metric',
    'C0603':  'Capacitor_SMD:C_0603_1608Metric',
    'C1210':  'Capacitor_SMD:C_1210_3225Metric',
    'ELEC':   'Capacitor_SMD:CP_Elec_6.3x7.7',
    'L1040':  'Inductor_SMD:L_10.4x10.4_H4.8',
    'BTN':    'Button_Switch_SMD:SW_Push_1P1T_NO_CK_KMR2',
    'HDR4':   'Connector_PinHeader_2.54mm:PinHeader_1x04_P2.54mm_Vertical',
    'HDR6':   'Connector_PinHeader_2.54mm:PinHeader_1x06_P2.54mm_Vertical',
    'LED':    'LED_SMD:LED_0603_1608Metric',
}

def tmc(ref, suffix, ms1_net):
    """TMC2209-LA pin map (KiCad official symbol numbering)."""
    s = suffix
    return (ref, FP['TMC'], 'TMC2209', {
        '1': f'M{s}_B2', '2': f'EN_{s}', '3': 'GND', '4': f'CPO_{s}', '5': f'CPI_{s}',
        '6': f'VCP_{s}', '7': 'GND', '8': f'V5OUT_{s}', '9': ms1_net, '10': 'GND',
        '11': f'DIAG_{s}', '12': '', '13': 'GND', '14': 'TMC_UART', '15': '+3V3',
        '16': f'STEP_{s}', '17': 'GND', '18': 'GND', '19': f'DIR_{s}', '20': 'GND',
        '21': f'M{s}_A2', '22': '+12V', '23': f'BRA_{s}', '24': f'M{s}_A1', '25': '',
        '26': f'M{s}_B1', '27': f'BRB_{s}', '28': '+12V', '29': 'GND',
    })

COMPONENTS = [
    # ---------------- power input ----------------
    ('J1', FP['TB2'], '12V_IN',     {'1': '+12V_IN', '2': 'GND'}),
    ('Q1', FP['SOIC8'], 'AO4407A',  {'1': '+12V', '2': '+12V', '3': '+12V', '4': 'QG',
                                     '5': '+12V_IN', '6': '+12V_IN', '7': '+12V_IN', '8': '+12V_IN'}),
    ('R1', FP['R0603'], '100k',     {'1': 'QG', '2': 'GND'}),
    ('D1', FP['SMB'], 'SMBJ16A',    {'1': 'GND', '2': '+12V'}),
    ('C1', FP['ELEC'], '100uF/25V', {'1': '+12V', '2': 'GND'}),
    ('C2', FP['ELEC'], '100uF/25V', {'1': '+12V', '2': 'GND'}),

    # ---------------- buck 12V -> 5.18V (TPS5450, non-sync, B540C catch) ----------------
    # TPS5450 SO-8: 1 BOOT, 2 NC, 3 NC, 4 VSENSE, 5 ENA, 6 GND, 7 VIN, 8 PH, 9 EP
    ('U1', FP['BUCK'], 'TPS5450DDAR', {'1': 'BOOT', '2': '', '3': '', '4': 'FB',
                                       '5': '', '6': 'GND', '7': '+12V', '8': 'SW', '9': 'GND'}),
    ('C3', FP['C1210'], '10uF/25V',   {'1': '+12V', '2': 'GND'}),
    ('C4', FP['C0603'], '100nF',      {'1': '+12V', '2': 'GND'}),
    ('C5', FP['C0603'], '10nF',       {'1': 'BOOT', '2': 'SW'}),
    ('D2', FP['SMC'], 'B540C',        {'1': 'SW', '2': 'GND'}),   # cathode=1 to SW, anode=2 GND
    ('L1', FP['L1040'], '10uH/7A',    {'1': 'SW', '2': '+5V1'}),
    ('R2', FP['R0603'], '32.4k',      {'1': '+5V1', '2': 'FB'}),
    ('R3', FP['R0603'], '10.0k',      {'1': 'FB', '2': 'GND'}),
    ('C6', FP['ELEC'], '100uF/10V',   {'1': '+5V1', '2': 'GND'}),
    ('C7', FP['C1210'], '22uF/10V',   {'1': '+5V1', '2': 'GND'}),
    ('C8', FP['C1210'], '22uF/10V',   {'1': '+5V1', '2': 'GND'}),

    # ---------------- USB-C power OUT to Pi 5 ----------------
    ('J2', FP['USB'], 'USB_C_PWR_OUT', {
        'A1': 'GND', 'A12': 'GND', 'B1': 'GND', 'B12': 'GND',
        'A4': '+5V1', 'A9': '+5V1', 'B4': '+5V1', 'B9': '+5V1',
        'A5': 'CC1_OUT', 'B5': 'CC2_OUT',
        'A6': '', 'A7': '', 'B6': '', 'B7': '', 'A8': '', 'B8': '', 'SH': 'GND'}),
    ('R4', FP['R0603'], '10k', {'1': '+5V1', '2': 'CC1_OUT'}),
    ('R5', FP['R0603'], '10k', {'1': '+5V1', '2': 'CC2_OUT'}),
    ('D4', FP['LED'], 'LED_PWR', {'1': 'PWRLED_K', '2': '+5V1'}),
    ('R6', FP['R0603'], '1k',  {'1': 'PWRLED_K', '2': 'GND'}),

    # ---------------- 3.3V LDO ----------------
    ('U4', FP['SOT223'], 'AMS1117-3.3', {'1': 'GND', '2': '+3V3', '3': 'VDD_LDO'}),
    ('D3', FP['SMA'], 'SS34',  {'1': 'VDD_LDO', '2': 'VBUS_PROG'}),  # cathode=1 to LDO node
    ('D5', FP['SMA'], 'SS34',  {'1': 'VDD_LDO', '2': '+5V1'}),
    ('C9', FP['C1210'], '22uF/10V', {'1': 'VDD_LDO', '2': 'GND'}),
    ('C10', FP['C1210'], '22uF/10V', {'1': '+3V3', '2': 'GND'}),
    ('C11', FP['C0603'], '100nF', {'1': '+3V3', '2': 'GND'}),

    # ---------------- ESP32-S3 module ----------------
    ('U5', FP['ESP'], 'ESP32-S3-WROOM-1-N8', {
        '1': 'GND', '2': '+3V3', '3': 'ESP_EN',
        '4': 'STEP_A', '5': 'DIR_A', '6': 'EN_A', '7': 'DIAG_A',
        '8': 'STEP_B', '9': 'DIR_B', '10': 'EN_B', '11': 'DIAG_B',
        '12': 'SPARE1', '13': 'USB_DN', '14': 'USB_DP', '15': '',
        '16': '', '17': 'ENDSTOP1', '18': 'ENDSTOP2', '19': 'SPARE2', '20': 'SPARE3',
        '21': 'SPARE4', '22': 'SPARE5', '23': 'TMC_TX', '24': 'TMC_UART', '25': 'STATLED',
        '26': '', '27': 'ESP_IO0', '28': '', '29': '', '30': '', '31': '', '32': '',
        '33': '', '34': '', '35': '', '36': 'ESP_RX0', '37': 'ESP_TX0', '38': '', '39': '',
        '40': 'GND', '41': 'GND'}),
    ('R7', FP['R0603'], '10k',   {'1': '+3V3', '2': 'ESP_EN'}),
    ('C12', FP['C0603'], '1uF',  {'1': 'ESP_EN', '2': 'GND'}),
    ('R8', FP['R0603'], '10k',   {'1': '+3V3', '2': 'ESP_IO0'}),
    ('SW1', FP['BTN'], 'RESET',  {'1': 'ESP_EN', '2': 'GND'}),
    ('SW2', FP['BTN'], 'BOOT',   {'1': 'ESP_IO0', '2': 'GND'}),
    ('C13', FP['C1210'], '22uF/10V', {'1': '+3V3', '2': 'GND'}),
    ('C14', FP['C0603'], '100nF', {'1': '+3V3', '2': 'GND'}),
    ('R9', FP['R0603'], '1k',    {'1': 'TMC_TX', '2': 'TMC_UART'}),
    ('D6', FP['LED'], 'LED_STAT', {'1': 'STATLED_K', '2': 'STATLED'}),
    ('R10', FP['R0603'], '1k',   {'1': 'STATLED_K', '2': 'GND'}),

    # ---------------- USB-C programming port ----------------
    ('J3', FP['USB'], 'USB_C_PROG', {
        'A1': 'GND', 'A12': 'GND', 'B1': 'GND', 'B12': 'GND',
        'A4': 'VBUS_PROG', 'A9': 'VBUS_PROG', 'B4': 'VBUS_PROG', 'B9': 'VBUS_PROG',
        'A5': 'CC1_PRG', 'B5': 'CC2_PRG',
        'A6': 'USB_DP', 'B6': 'USB_DP', 'A7': 'USB_DN', 'B7': 'USB_DN',
        'A8': '', 'B8': '', 'SH': 'GND'}),
    ('R11', FP['R0603'], '5.1k', {'1': 'CC1_PRG', '2': 'GND'}),
    ('R12', FP['R0603'], '5.1k', {'1': 'CC2_PRG', '2': 'GND'}),

    # ---------------- TMC2209 x2 ----------------
    tmc('U2', 'A', 'GND'),      # UART address 0
    tmc('U3', 'B', '+3V3'),     # UART address 1
    # per-driver support parts, A:
    ('C15', FP['C0603'], '22nF',  {'1': 'CPO_A', '2': 'CPI_A'}),
    ('C16', FP['C0603'], '100nF', {'1': 'VCP_A', '2': '+12V'}),
    ('C17', FP['C0603'], '470nF', {'1': 'V5OUT_A', '2': 'GND'}),
    ('C18', FP['C0603'], '100nF', {'1': '+3V3', '2': 'GND'}),
    ('C19', FP['C0603'], '100nF', {'1': '+12V', '2': 'GND'}),
    ('R13', FP['R1206'], '110m',  {'1': 'BRA_A', '2': 'GND'}),
    ('R14', FP['R1206'], '110m',  {'1': 'BRB_A', '2': 'GND'}),
    # B:
    ('C20', FP['C0603'], '22nF',  {'1': 'CPO_B', '2': 'CPI_B'}),
    ('C21', FP['C0603'], '100nF', {'1': 'VCP_B', '2': '+12V'}),
    ('C22', FP['C0603'], '470nF', {'1': 'V5OUT_B', '2': 'GND'}),
    ('C23', FP['C0603'], '100nF', {'1': '+3V3', '2': 'GND'}),
    ('C24', FP['C0603'], '100nF', {'1': '+12V', '2': 'GND'}),
    ('R15', FP['R1206'], '110m',  {'1': 'BRA_B', '2': 'GND'}),
    ('R16', FP['R1206'], '110m',  {'1': 'BRB_B', '2': 'GND'}),

    # ---------------- motor terminals ----------------
    # pin order chosen to match the TMC's natural left-to-right escape: B2 B1 | A1 A2
    ('J4', FP['TB4'], 'MOTOR_A', {'1': 'MA_B2', '2': 'MA_B1', '3': 'MA_A1', '4': 'MA_A2'}),
    ('J5', FP['TB4'], 'MOTOR_B', {'1': 'MB_B2', '2': 'MB_B1', '3': 'MB_A1', '4': 'MB_A2'}),

    # ---------------- headers ----------------
    ('J6', FP['HDR4'], 'ENDSTOPS', {'1': '+3V3', '2': 'ENDSTOP1', '3': 'ENDSTOP2', '4': 'GND'}),
    ('J7', FP['HDR6'], 'SPARE',    {'1': '+3V3', '2': 'GND', '3': 'SPARE1', '4': 'SPARE2',
                                    '5': 'SPARE3', '6': 'SPARE4'}),

    # ---------------- mounting ----------------
    ('H1', 'MountingHole:MountingHole_3.2mm_M3', 'M3', {}),
    ('H2', 'MountingHole:MountingHole_3.2mm_M3', 'M3', {}),
    ('H3', 'MountingHole:MountingHole_3.2mm_M3', 'M3', {}),
    ('H4', 'MountingHole:MountingHole_3.2mm_M3', 'M3', {}),
]

# placement: (ref) -> (x, y, rot_deg)   board outline 0,0 .. 92,60
# v2: computed from measured courtyard extents; every same-side courtyard pair
# verified non-overlapping on paper. Antenna keepout slab of U5 projects off-board.
PLACEMENT = {
    # --- 12V input, top-left: J1 -> Q1 (reverse PFET, IN pads left) -> C1/C2 bulk below ---
    'J1': (5.2, 16, 90),    'Q1': (15.5, 9, 180),  'R1': (13, 13.3, 0),  'D1': (15.5, 16.5, 0),
    'C1': (16, 22.5, 0),    'C2': (16, 30, 0),
    # --- buck, lower-left: U1 SW->L1->C6/C7/C8; D2 catch below; FB divider west ---
    'U1': (13, 40, 0),      'C4': (13, 35.4, 180), 'C3': (17.5, 35.4, 180), 'C5': (19.6, 38.3, 180),
    'D2': (16.5, 48.5, 0),  'L1': (27.5, 40, 0),
    'R2': (5, 44, 90),      'R3': (7.5, 44, 270),
    'C6': (38.3, 40, 0),    'C7': (33.3, 48.3, 90),'C8': (37, 48.3, 90),
    # --- USB-C 5V out, bottom-left ---
    'J2': (30, 54.85, 180),  'R4': (28.7, 47.6, 180), 'R5': (28.7, 49.4, 180),
    'D4': (37, 54.5, 90),   'R6': (39.5, 54.5, 270),
    # --- TMC A under its terminal ---
    'U2': (33.5, 17, 0),    'J4': (26, 4.6, 0),
    'R14': (27.7, 11.8, 90), 'R13': (39.2, 11.8, 90), 'C19': (42.6, 12, 90),
    'C15': (28, 18.6, 270), 'C16': (28, 21.8, 270),
    'C17': (31, 22.5, 180), 'C18': (35.3, 22.5, 0),
    # --- TMC B mirror ---
    'U3': (59.5, 17, 0),    'J5': (52, 4.6, 0),
    'R16': (53.7, 11.8, 90), 'R15': (65.2, 11.8, 90), 'C24': (68.6, 12, 90),
    'C20': (54, 18.6, 270), 'C21': (54, 21.8, 270),
    'C22': (57, 22.5, 180), 'C23': (61.3, 22.5, 0),
    # --- ESP32-S3, right edge, antenna + keepout slab off-board ---
    'U5': (85, 33, 270),
    'C14': (72, 21.5, 0),   'C13': (76.5, 21.2, 0), 'C12': (82.5, 21.5, 180), 'R7': (86.5, 21.5, 180),
    'R9': (70, 36.5, 270),  'D6': (68, 40, 0),      'R10': (63.5, 40, 180),
    'R8': (74.5, 45, 0),    'SW2': (80, 46, 0),     'SW1': (86, 46, 0),
    # --- 3.3V LDO cluster, center-bottom ---
    'U4': (51.5, 44, 0),    'D5': (42.5, 46.3, 180),'D3': (42.5, 50.3, 180),
    'C9': (45, 41, 90),     'C10': (58, 44, 90),    'C11': (61, 44, 90),
    # --- USB-C prog port + CC resistors ---
    'J3': (57.5, 54.85, 180),'R11': (47.5, 52, 90),  'R12': (49.5, 52, 90),
    # --- headers, bottom-right ---
    'J6': (65, 52.5, 90),   'J7': (65, 57, 90),
    # --- mounting holes ---
    'H1': (3.5, 3.5, 0),    'H2': (3.5, 56.5, 0),
    'H3': (88.5, 3.5, 0),   'H4': (88, 56, 0),
}

BOARD = (0.0, 0.0, 92.0, 60.0)
