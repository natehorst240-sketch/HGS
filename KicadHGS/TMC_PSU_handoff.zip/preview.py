#!/usr/bin/env python3
"""Placement preview: pads, courtyards, refs, ratsnest (MST per net). Flags courtyard overlaps."""
import pcbnew, math, sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Circle
from matplotlib.collections import LineCollection

TM = pcbnew.ToMM
b = pcbnew.LoadBoard('/home/claude/tmc/TMC_PSU.kicad_pcb')

fig, ax = plt.subplots(figsize=(18, 12))
ax.set_aspect('equal')

# outline
for d in b.GetDrawings():
    if d.GetLayerName() == 'Edge.Cuts':
        s, e = d.GetStart(), d.GetEnd()
        ax.plot([TM(s.x), TM(e.x)], [TM(s.y), TM(e.y)], 'k-', lw=1.5)

# footprints: courtyard bbox, pads, ref
courts = []  # (ref, side, x0,y0,x1,y1)
for f in b.GetFootprints():
    ref = f.GetReference()
    side = 'B' if f.IsFlipped() else 'F'
    # courtyard bbox via footprint bounding box of courtyard layer shapes
    cb = f.GetCourtyard(pcbnew.F_CrtYd if side == 'F' else pcbnew.B_CrtYd)
    if cb.OutlineCount() > 0:
        bb = cb.BBox()
        x0, y0, x1, y1 = TM(bb.GetLeft()), TM(bb.GetTop()), TM(bb.GetRight()), TM(bb.GetBottom())
    else:
        bb = f.GetBoundingBox(False)
        x0, y0, x1, y1 = TM(bb.GetLeft()), TM(bb.GetTop()), TM(bb.GetRight()), TM(bb.GetBottom())
    courts.append((ref, side, x0, y0, x1, y1))
    color = '#1f77b4' if side == 'F' else '#d62728'
    ax.add_patch(Rectangle((x0, y0), x1-x0, y1-y0, fill=False, ec=color, lw=0.7, alpha=0.6))
    p = f.GetPosition()
    ax.annotate(ref, (TM(p.x), TM(p.y)), fontsize=7, ha='center', va='center',
                color='black', weight='bold', zorder=6)
    for pad in f.Pads():
        pp = pad.GetPosition()
        px, py = TM(pp.x), TM(pp.y)
        sz = pad.GetSize(pcbnew.F_Cu if side == 'F' else pcbnew.B_Cu)
        sx, sy = TM(sz.x), TM(sz.y)
        ang = pad.GetOrientationDegrees() % 180
        if 45 < ang < 135: sx, sy = sy, sx
        if pad.GetAttribute() == pcbnew.PAD_ATTRIB_PTH:
            ax.add_patch(Circle((px, py), max(sx, sy)/2, fc='#c8b400', ec='none', alpha=0.8, zorder=3))
        else:
            fc = '#e06060' if side == 'F' else '#6060e0'
            ax.add_patch(Rectangle((px-sx/2, py-sy/2), sx, sy, fc=fc, ec='none', alpha=0.75, zorder=3))

# courtyard overlap check: true polygons (bbox prefilter, then boolean intersection)
polys = {}
for f in b.GetFootprints():
    cp = f.GetCourtyard(pcbnew.F_CrtYd)
    if cp.OutlineCount() > 0:
        polys[f.GetReference()] = cp
overlaps = []
for i in range(len(courts)):
    for j in range(i+1, len(courts)):
        r1, s1, a0, b0, a1, b1 = courts[i]
        r2, s2, c0, d0, c1, d1 = courts[j]
        if s1 != s2: continue
        ox = min(a1, c1) - max(a0, c0)
        oy = min(b1, d1) - max(b0, d0)
        if ox > 0.01 and oy > 0.01:
            if r1 in polys and r2 in polys:
                inter = pcbnew.SHAPE_POLY_SET(polys[r1])
                try:
                    inter.BooleanIntersection(polys[r2])
                except TypeError:
                    inter.BooleanIntersection(polys[r2], pcbnew.SHAPE_POLY_SET.PM_FAST)
                area = inter.Area() / 1e12  # nm^2 -> mm^2
                if area < 0.001:
                    continue
                overlaps.append((r1, r2, round(area, 2)))
            else:
                overlaps.append((r1, r2, round(ox, 2), round(oy, 2)))

# off-board check: courtyard beyond outline, minus intentional overhangs
ALLOW = {'U5': 'antenna+keepout off right edge', 'J2': 'USB mouth', 'J3': 'USB mouth'}
BX0, BY0, BX1, BY1 = 0.0, 0.0, 92.0, 60.0
offboard = []
for ref, side, x0c, y0c, x1c, y1c in courts:
    if ref in ALLOW: continue
    if x0c < BX0 - 0.01 or y0c < BY0 - 0.01 or x1c > BX1 + 0.01 or y1c > BY1 + 0.01:
        offboard.append((ref, round(x0c, 1), round(y0c, 1), round(x1c, 1), round(y1c, 1)))

# ratsnest: MST per net over pad positions
pads_by_net = {}
for f in b.GetFootprints():
    for pad in f.Pads():
        n = pad.GetNetname()
        if n and n != 'GND':   # GND goes to planes
            pp = pad.GetPosition()
            pads_by_net.setdefault(n, []).append((TM(pp.x), TM(pp.y)))
lines = []
total = 0
for n, pts in pads_by_net.items():
    if len(pts) < 2: continue
    # dedupe identical points
    pts = list(dict.fromkeys(pts))
    if len(pts) < 2: continue
    in_t = {0}
    out_t = set(range(1, len(pts)))
    while out_t:
        best = None
        for a in in_t:
            for c in out_t:
                d = math.hypot(pts[a][0]-pts[c][0], pts[a][1]-pts[c][1])
                if best is None or d < best[0]: best = (d, a, c)
        d, a, c = best
        lines.append([pts[a], pts[c]])
        total += 1
        in_t.add(c); out_t.remove(c)
ax.add_collection(LineCollection(lines, colors='#00a000', linewidths=0.5, alpha=0.55, zorder=2))

# crossing count
def seg_int(p1, p2, p3, p4):
    def ccw(A, B, C): return (C[1]-A[1])*(B[0]-A[0]) > (B[1]-A[1])*(C[0]-A[0])
    if p1 in (p3, p4) or p2 in (p3, p4): return False
    return ccw(p1,p3,p4) != ccw(p2,p3,p4) and ccw(p1,p2,p3) != ccw(p1,p2,p4)
x = 0
for i in range(len(lines)):
    for j in range(i+1, len(lines)):
        if seg_int(lines[i][0], lines[i][1], lines[j][0], lines[j][1]): x += 1

ax.invert_yaxis()
ax.set_title(f'TMC_PSU placement — {total} ratsnest edges, {x} crossings, {len(overlaps)} courtyard overlaps')
ax.set_xlabel('mm'); ax.set_ylabel('mm')
ax.grid(True, alpha=0.2)
plt.tight_layout()
plt.savefig('/home/claude/tmc/placement_preview.png', dpi=130)
print(f"ratsnest edges={total} crossings={x}")
print("courtyard overlaps:", overlaps if overlaps else "NONE")
print("off-board courtyards:", offboard if offboard else "NONE")
