#!/usr/bin/env python3
"""Build the .kicad_pcb from design.py: outline, footprints from stock libs, nets, placement."""
import pcbnew, sys, os
sys.path.insert(0, '/home/claude/tmc')
from design import COMPONENTS, PLACEMENT, BOARD

FM = pcbnew.FromMM
OUT = '/home/claude/tmc/TMC_PSU.kicad_pcb'

board = pcbnew.CreateEmptyBoard()

# ---- nets ----
netnames = set()
for ref, fp, val, pads in COMPONENTS:
    for net in pads.values():
        if net: netnames.add(net)
nets = {}
for n in sorted(netnames):
    ni = pcbnew.NETINFO_ITEM(board, n)
    board.Add(ni)
    nets[n] = ni
print(f"nets: {len(nets)}")

# ---- outline ----
x0, y0, x1, y1 = BOARD
for (ax, ay, bx, by) in [(x0,y0,x1,y0),(x1,y0,x1,y1),(x1,y1,x0,y1),(x0,y1,x0,y0)]:
    seg = pcbnew.PCB_SHAPE(board)
    seg.SetShape(pcbnew.SHAPE_T_SEGMENT)
    seg.SetStart(pcbnew.VECTOR2I(FM(ax), FM(ay)))
    seg.SetEnd(pcbnew.VECTOR2I(FM(bx), FM(by)))
    seg.SetLayer(pcbnew.Edge_Cuts)
    seg.SetWidth(FM(0.1))
    board.Add(seg)

# ---- footprints ----
FPBASE = '/usr/share/kicad/footprints'
missing = []
for ref, fpid, val, pads in COMPONENTS:
    lib, name = fpid.split(':')
    fp = pcbnew.FootprintLoad(f'{FPBASE}/{lib}.pretty', name)
    if fp is None:
        missing.append(fpid); continue
    fp.SetReference(ref)
    fp.SetValue(val)
    if ref not in PLACEMENT:
        missing.append(f'no placement {ref}'); continue
    x, y, rot = PLACEMENT[ref]
    fp.SetPosition(pcbnew.VECTOR2I(FM(x), FM(y)))
    fp.SetOrientationDegrees(rot)
    # net assignment
    for pad in fp.Pads():
        num = pad.GetNumber()
        net = pads.get(num, None)
        if net:
            pad.SetNet(nets[net])
    board.Add(fp)
if missing:
    print("MISSING:", missing); sys.exit(1)
print(f"footprints placed: {len(list(board.GetFootprints()))}")

# ---- design rules ----
d = board.GetDesignSettings()
d.m_MinClearance = FM(0.15)
d.m_TrackMinWidth = FM(0.2)
d.m_ViasMinSize = FM(0.5)
d.m_MinThroughDrill = FM(0.2)
d.m_CopperEdgeClearance = FM(0.3)
# default netclass: 0.15 clearance so it doesn't override the board minimum
dc = d.m_NetSettings.GetDefaultNetclass()
dc.SetClearance(FM(0.15))
dc.SetTrackWidth(FM(0.25))
dc.SetViaDiameter(FM(0.6))
dc.SetViaDrill(FM(0.3))

# ---- GND zones both layers + 12V pour on B.Cu around motor section ----
for layer in (pcbnew.F_Cu, pcbnew.B_Cu):
    z = pcbnew.ZONE(board)
    z.SetLayer(layer)
    z.SetNet(nets['GND'])
    o = z.Outline(); o.NewOutline()
    for px, py in [(x0, y0), (x1, y0), (x1, y1), (x0, y1)]:
        o.Append(FM(px), FM(py))
    z.SetPadConnection(pcbnew.ZONE_CONNECTION_FULL)
    z.SetLocalClearance(FM(0.2))
    z.SetMinThickness(FM(0.25))
    z.SetAssignedPriority(0)
    board.Add(z)

pcbnew.SaveBoard(OUT, board)
print("saved", OUT)

# ---- audit: every pad net vs design ----
b2 = pcbnew.LoadBoard(OUT)
want = {(r, num): net for r, _, _, pads in COMPONENTS for num, net in pads.items() if net}
got = {}
for f in b2.GetFootprints():
    for p in f.Pads():
        if p.GetNetname():
            got[(f.GetReference(), p.GetNumber())] = p.GetNetname()
bad = {k: (want.get(k), got.get(k)) for k in set(want) | set(got) if want.get(k) != got.get(k)}
print("net audit mismatches:", bad if bad else "NONE")
print("pads with nets:", len(got))
EOF_MARKER_NOT_USED = None
